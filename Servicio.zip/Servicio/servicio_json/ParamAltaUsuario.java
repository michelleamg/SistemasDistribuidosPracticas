/*
  Carlos Pineda Guerrero, septiembre 2024
*/

package servicio_json;

public class ParamAltaUsuario 
{
  Usuario usuario;
}
